%�����ѹ����ѹ
%����EPOCH�еĴų����ȳ��������ѹ����ѹ
%�ȼ����ѹ
clear all;clc;close all;
%�糡�ݻ�
path1='E:\Weibel_large\';
path_in='E:\Shock\Ex'; % path_in Ϊgif����·��
T=140;
mu= 1.26e-6;
for i=500:500
Fig=figure;
 %��׼������
 %���ж���λ��
 if(i/1000>=1)
     str=num2str(i);
 end
 if(i/1000<1&i/100>=1)
       str=['0',num2str(i)];
  end
  if(i/1000<1&i/100<1&i/10>=1)
           str=['00',num2str(i)];
  end
  if(i/1000<1&i/100<1&i/10<1)
           str=['000',num2str(i)];
  end
 input=[path1,str,'.sdf']
 data=GetDataSDF(input)
 Bz=data.Magnetic_Field.Bz.data;
 Bx=data.Magnetic_Field.Bx.data;
 By=data.Magnetic_Field.By.data;
 Ex=data.Electric_Field.Ex.data;
 mag=(Bz.^2+Bx.^2+By.^2)/(2*mu);
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

n_DT2=data.Derived.Number_Density.DT2.data;
n_DT=data.Derived.Number_Density.DT.data;
T_DT2=data.Derived.Average_Particle_Energy.DT2.data;
T_DT=data.Derived.Average_Particle_Energy.DT.data;  
P_DT2=n_DT2.*T_DT2;
P_DT=n_DT.*T_DT;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
xstart=1;
xend=239;
L=24000/(240)*(xend-xstart);
x=linspace(xstart,xend,L);
y=linspace(-100,100,400);

figure;
imagesc(x,y,mag');
xlabel(' x/\mum','fontsize',16)
ylabel('y/\mum','fontsize',16)
ylabel(colorbar,'\fontsize{16} J_x/(A)')
colormap(jet);
colorbar;
axis square;
set(gca,'fontsize',16)
ylabel(colorbar,'\fontsize{16} P_B/Pa') 
;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
figure;
imagesc(x,y,P_DT'/3);
xlabel(' x/\mum','fontsize',16)
ylabel('y/\mum','fontsize',16)
colormap(jet);
colorbar;
set(gca,'fontsize',16)
ylabel(colorbar,'\fontsize{16} P_{T_{H_l}}/Pa') 

axis square;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
figure;
imagesc(x,y,P_DT2'/3);
xlabel(' x/\mum','fontsize',16)
ylabel('y/\mum','fontsize',16)
colormap(jet);
colorbar;
axis square;
set(gca,'fontsize',16)
ylabel(colorbar,'\fontsize{16} P_{T_{H_r}}/Pa') 


end