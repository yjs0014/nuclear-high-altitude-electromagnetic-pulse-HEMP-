%EPOCH��ͼ����
%�ų������ݻ�
clear all;clc;
path1='E:\Weibel_large\\';
path_in='E:\Weibel_large\\'; % path_in Ϊgif����·��
%�ܵ��ļ�����
avi_object=VideoWriter('E:\Weibel_large\1.avi');
open(avi_object);
T=28;

for i=0:T
Fig=figure;
 %��׼������
 %���ж���λ��
 if(i/1000>=1)
     str=num2str(i);
 end
 if(i/1000<1&i/100>=1)
       str=['0',num2str(i)];
  end
  if(i/1000<1&i/100<1&i/10>=1)
           str=['00',num2str(i)];
  end
  if(i/1000<1&i/100<1&i/10<1)
           str=['000',num2str(i)];
  end
 input=[path1,str,'.sdf']
 data=GetDataSDF(input)

 Bx=data.Magnetic_Field.Bx.data;
 By=data.Magnetic_Field.By.data;
 jz=data.Current.Jz.data;
NL=length(Bx);
x=linspace(0,3600,NL);
y=linspace(0,3600,NL);
imagesc(x,y,jz);
%caxis([-0.18 0.18]) 
hold on;
[X,Y] = meshgrid(x,y);
%A2=
%contour(X,Y,A2,'LevelStep',0.5)
%title(['t=',num2str(tt),'\Omega_{i}^{-1}'])
 colorbar
 set(gca,'YDir','normal');
 p=colorbar;
 set(get(p,'label'),'string','\fontsize{13} J_{z}'); 
 colormap(jet)
  %caxis([-0.08 0.08])
axis square;
 

M = getframe;
% the M is writed to avi_object by writeVideo function 
    writeVideo(avi_object, M);
saveas(gcf,[path_in,num2str(i)],'png'); 
 close
 end
close(avi_object)        
     
