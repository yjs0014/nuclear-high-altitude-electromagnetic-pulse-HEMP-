%EPOCH��ͼ����
%��ռ���ݻ�
clear all;clc;
path1='H:\injector\';
path_in='H:\injector\'; % path_in Ϊgif����·��
%�ܵ��ļ�����
avi_object=VideoWriter('H:\injector\movie01.avi');
open(avi_object);
T=100;
for i=1:T
Fig=figure;
 %��׼������
 %���ж���λ��
 if(i/1000>=1)
     str=num2str(i);
 end
 if(i/1000<1&i/100>=1)
       str=['0',num2str(i)];
  end
  if(i/1000<1&i/100<1&i/10>=1)
           str=['00',num2str(i)];
  end
  if(i/1000<1&i/100<1&i/10<1)
           str=['000',num2str(i)];
  end
 input=[path1,str,'.sdf']
 data=GetDataSDF(input)
 V1=data.Particles.Px.left.data;
 X1=data.Particles.Px.left.grid.x;
 V2=data.Particles.Px.right.data;
 X2=data.Particles.Px.right.grid.x;
 scatter(X1,V1,0.5,'k')
 axis square;
 box on;
 hold on;
 scatter(X2,V2,0.5,'r')
 xlabel('x');
 ylabel('Px');
 axis square;
 xlim([0 5*10^5])
 ylim([-10*10^(-24) 10*10^(-24)])
 box on;
 hold off;
%  frame = getframe(Fig); 
%     im = frame2im(frame); 
%     [imind,cm] = rgb2ind(im,256);
%     if(i==1)
%         imwrite(imind,cm,'F:\EPOCH\output\output\phase.gif','gif','WriteMode','overwrite', 'Loopcount',inf);
%     else
%         imwrite(imind,cm,'F:\EPOCH\output\output\phase.gif','gif','WriteMode','append','DelayTime',0.25);
%     end

M = getframe;
% the M is writed to avi_object by writeVideo function 
    writeVideo(avi_object, M);
saveas(gcf,[path_in,num2str(i)],'png'); 
 close
 end
close(avi_object)        
     
