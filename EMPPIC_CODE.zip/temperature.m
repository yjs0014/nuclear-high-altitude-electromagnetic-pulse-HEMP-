clear all;clc;close all;
%�糡�ݻ�
path1='H:\Shock_DT\Pluto2\';
path_in='E:\Shock\Density\'; % path_in Ϊgif����·��
T=140;

for i=20:20
Fig=figure;
 %��׼������
 %���ж���λ��
 if(i/1000>=1)
     str=num2str(i);
 end
 if(i/1000<1&i/100>=1)
       str=['0',num2str(i)];
  end
  if(i/1000<1&i/100<1&i/10>=1)
           str=['00',num2str(i)];
  end
  if(i/1000<1&i/100<1&i/10<1)
           str=['000',num2str(i)];
  end
 input=[path1,str,'.sdf']
 data=GetDataSDF(input)

x_electronl=data.Particles.Vx.subset_parti.electronl.grid.x;
Vx_electronl=data.Particles.Vx.subset_parti.electronl.data;
Vy_electronl=data.Particles.Vy.subset_parti.electronl.data;
Vz_electronl=data.Particles.Vz.subset_parti.electronl.data;
electronl=[x_electronl,Vx_electronl];
sort_el=sortrows(electronl,1);
Left=12e-6;
Right=13e-6;
dl=(Right-Left)/99;
Velectronl=[];
Tel=[];
x=linspace(Left,Right,100);
for j=1:100
xl=Left+(j-1)*dl;
xr=Left+j*dl;
lel=find(sort_el(:,1)<xr&sort_el(:,1)>xl);
electronl_sort=sort_el(lel,:);
% Xelectronl=electronl_sort(:,1);
Vel1=electronl_sort(:,2);
Mean=mean(Vel1);
Vel2=Vel1-0;
Velectronl=[Velectronl;Vel2];
Tel1=0.5*sum(Vel2.^2)/length(Vel2);
Tel=[Tel;Tel1];
end
% Vmin=min(Velectronl);
% Vmax=max(Velectronl);
% v=lin
%Celectronl=linspace(-1e8,1e8,1000);


[felectronl,Celectronl]=hist(Velectronl,1000);
W_el=1.e27*4.e-7*60e-6/(12000*40)/256;
% figure;
% plot(Celectronl,felectronl.*W_el)

x_electronr=data.Particles.Vx.subset_parti.electronr.grid.x;
Vx_electronr=data.Particles.Vx.subset_parti.electronr.data;
Vy_electronr=data.Particles.Vy.subset_parti.electronr.data;
Vz_electronr=data.Particles.Vz.subset_parti.electronr.data;
electronr=[x_electronr,Vx_electronr];
sort_er=sortrows(electronr,1);
Velectronr=[];
Ter=[];
for j=1:100
xl=Left+(j-1)*dl;
xr=Left+j*dl;
ler=find(sort_er(:,1)<xr&sort_er(:,1)>xl);
electronr_sort=sort_er(ler,:);
% Xelectronl=electronl_sort(:,1);
Ver1=electronr_sort(:,2);
Mean=mean(Ver1);
Ver2=Ver1-0;
Velectronr=[Velectronr;Ver2];
Ter1=0.5*sum(Ver2.^2)/length(Ver2);
Ter=[Ter;Ter1];
end
% Vmin=min(Velectronl);
% Vmax=max(Velectronl);
% v=lin
[felectronr,Celectronr]=hist(Velectronr,Celectronl);
W_er=5.e25*4.e-7*60e-6/(12000*40)/256;
% figure;
% plot(Celectronr,felectronr.*W_er)

Nminus=felectronr.*W_er+felectronl.*W_el;
% Initial=load('H:\Shock_Au_C\inital.mat');
% x=Initial.Data(:,1);
% v=Initial.Data(:,2);
plot(Celectronr,smooth(Nminus,10),'r',Celectronr,smooth(felectronr.*W_er,2),...
    'k',Celectronr,smooth(felectronl.*W_el,10),'b')%,x,smooth(0.95*v,10),'b--');
axis square;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% x_Au=data.Particles.Vx.subset_parti.Au.grid.x;
% Vx_Au=data.Particles.Vx.subset_parti.Au.data;
% Vy_Au=data.Particles.Vy.subset_parti.Au.data;
% Vz_Au=data.Particles.Vz.subset_parti.Au.data;
% Au=[x_Au,Vx_Au];
% sort_Au=sortrows(Au,1);
% 
% % Xelectronl=electronl_sort(:,1);
% VAu=[];
% TAu=[];
% for j=1:100
% xl=Left+(j-1)*dl;
% xr=Left+j*dl;
% ler=find(sort_Au(:,1)<xr&sort_Au(:,1)>xl);
% Au_sort=sort_Au(ler,:);
% % Xelectronl=electronl_sort(:,1);
% VAu1=Au_sort(:,2);
% Mean=mean(VAu1);
% VAu2=VAu1-Mean;
% VAu=[VAu;VAu2];
% TAu1=0.5*sum(VAu2.^2)/length(VAu2);
% TAu=[TAu;TAu1];
% end
% 
% 
% % Vmin=min(Velectronl);
% % Vmax=max(Velectronl);
% % v=lin
% [fAu,CAu]=hist(VAu,Celectronl);
% W_Au=0.6e27*4.e-6*80e-6/(8000*40)/400;
% % figure;
% % plot(CAu,fAu.*W_Au)
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% x_C=data.Particles.Vx.subset_parti.C.grid.x;
% Vx_C=data.Particles.Vx.subset_parti.C.data;
% Vy_C=data.Particles.Vy.subset_parti.C.data;
% Vz_C=data.Particles.Vz.subset_parti.C.data;
% C=[x_C,Vx_C];
% sort_C=sortrows(C,1);
% VC=[];
% TC=[];
% for j=1:100
% xl=Left+(j-1)*dl;
% xr=Left+j*dl;
% ler=find(sort_C(:,1)<xr&sort_C(:,1)>xl);
% C_sort=sort_C(ler,:);
% % Xelectronl=electronl_sort(:,1);
% VC1=C_sort(:,2);
% Mean=mean(VC1);
% VC2=VC1-Mean;
% VC=[VC;VC2];
% TC1=0.5*sum(VC2.^2)/length(VC2);
% TC=[TC;TC1];
% end
% 
% [fC,CC]=hist(VC,Celectronl);
% W_C=2e25*4.e-6*80e-6/(8000*40)/400;
% % figure;
% % plot(CC,fC.*W_C)
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% x_H=data.Particles.Vx.subset_parti.H.grid.x;
% Vx_H=data.Particles.Vx.subset_parti.H.data;
% Vy_H=data.Particles.Vy.subset_parti.H.data;
% Vz_H=data.Particles.Vz.subset_parti.H.data;
% H=[x_H,Vx_H];
% sort_H=sortrows(H,1);
% VH=[];
% TH=[];
% for j=1:100
% xl=Left+(j-1)*dl;
% xr=Left+j*dl;
% ler=find(sort_H(:,1)<xr&sort_H(:,1)>xl);
% H_sort=sort_H(ler,:);
% % Xelectronl=electronl_sort(:,1);
% VH1=H_sort(:,2);
% Mean=mean(VH1);
% VH2=VH1-Mean;
% VH=[VH;VH2];
% TH1=0.5*sum(VH2.^2)/length(VH2);
% TH=[TH;TH1];
% end
% % Vmin=min(Velectronl);
% % Vmax=max(Velectronl);
% % v=lin
% [fH,CH]=hist(VH,Celectronl);
% W_H=2e25*4.e-6*80e-6/(8000*40)/400;
% Nplus=fH.*W_H+fC.*W_C+fAu.*W_Au;
% % figure
% % plot(Celectronl,Nminus,CH,fH.*W_H+fC.*W_C+fAu.*W_Au)
% plot(CH,Nminus)
% 
% % xstart=6;
% % xend=16;
% % L=8000/40*(xend-xstart);
% % x=linspace(xstart,xend,L);
% % Lstart=8000/40*xstart;
% % Lend=Lstart+L-1;
% % s=Lstart:Lend;
% % 
% % M_el=0.6e27;
% % M_er=4.e25;
% % M_Au=0.6e27;
% % M_C=2.e25;
% % M_H=2.e25;
% % 
% % p=plot(x,Mean_electronl(s)/M_el,'r-^',x,Mean_Au(s)/M_Au,'r-',x,Mean_electronr(s)/M_er,'k-^',...
% %    x,Mean_C(s)/M_C,'k-',  x,Mean_H(s)/M_H,'k--')
% % p(2).LineWidth=2;
% % p(4).LineWidth=2;
% % p(5).LineWidth=2;
% % xlabel('\fontsize{16} x/\mum')
% % ylabel('\fontsize{16} n/n_0')
% % legend('\fontsize{13} electron_l','\fontsize{13} Au','\fontsize{13} electron_r','\fontsize{13} C','\fontsize{13} H','location','BestOutside')
% % axis square;
% % set(gca,'fontsize',16)
% % set(gca,'xminortick','on');
% % set(gca,'yminortick','on');
% % xlim([7 13])
% % %M = getframe;
% % % the M is writed to avi_object by writeVideo function 
% %   %  writeVideo(avi_object, M);
% % saveas(gcf,[path_in,num2str(i)],'png'); 
%  %close
%  %Tem=mean(data.Derived.Temperature.data');
 end



% 
% Data=[Celectronl;Nminus];
% save 'H:\Shock_Au_C\inital.mat' Data




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% figure;
% nPlus=Mean_Au(s)*1+Mean_H(s)+Mean_C(s);
%nPlus=Mean_Au(s)*1;
%nMinus=Mean_electronl(s)+Mean_electronr(s);
% nMinus=Mean_electronl(s);
% p=plot(x,smooth(nPlus,4),'k',x,smooth(nMinus,4),'r')
% p(1).LineWidth=2;
% p(2).LineWidth=2;
% xlim([7. 13])
% xlabel('\fontsize{16} x/\mum')
% ylabel('\fontsize{16} n/n_0')
% axis square;
% set(gca,'fontsize',15)
% set(gca,'xminortick','on');
% set(gca,'yminortick','on');
% legend('\fontsize{16} N^{+}','\fontsize{16} N^{-}')
% 
% figure;
% Nplus=nPlus-nMinus;
% p=plot(x,smooth(Nplus,8))
% p(1).LineWidth=2;
% % p(2).LineWidth=2;
% xlim([10. 13])
% xlabel('\fontsize{16} x/\mum')
% ylabel('\fontsize{16} n/n_0')
% axis square;
% set(gca,'fontsize',15)
% set(gca,'xminortick','on');
% set(gca,'yminortick','on');
% legend('\fontsize{16} N^{+}-N^{-}')