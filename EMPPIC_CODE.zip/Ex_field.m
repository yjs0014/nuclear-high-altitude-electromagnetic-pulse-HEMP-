clear all;clc;close all;
%�糡�ݻ�
path1='E:\Weibel_large\';
path_in='E:\Shock\Ex'; % path_in Ϊgif����·��
T=140;

j=[linspace(10,500,50)];
for i=j
%Fig=figure;
 %��׼������
 %���ж���λ��
 if(i/1000>=1)
     str=num2str(i);
 end
 if(i/1000<1&i/100>=1)
       str=['0',num2str(i)];
  end
  if(i/1000<1&i/100<1&i/10>=1)
           str=['00',num2str(i)];
  end
  if(i/1000<1&i/100<1&i/10<1)
           str=['000',num2str(i)];
  end
 input=[path1,str,'.sdf']
 data=GetDataSDF(input)
 Bz=data.Magnetic_Field.Bz.data;
 Ey=data.Electric_Field.Ey.data;
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 xstart=1;
xend=120;
L=12000/(120)*(xend-xstart);
x=linspace(xstart,xend,L);
y=linspace(-50,50,100);
Lstart=12000/(120)*xstart;
Lend=Lstart+L;
%imagesc(x,y,interp2((Ey(Lstart:Lend,:)')));
% axis square;
% colormap(jet);
% c=colorbar;
% %xlim([5 30])
% %caxis([-2e10 10e10])
% set(gca,'fontsize',16)
% xlabel(' x/\mum','fontsize',16)
% ylabel('y/\mum','fontsize',16)
% %ylabel(colorbar,'\fontsize{16} E_x/(Vm^{-1})')
% ylabel(colorbar,'\fontsize{16} B_z/(T)')
% set(gca,'Ydir','normal');
if i==1
    m=1;
else
    m=floor(i/10);
end

MaxBz(m)=max(max(Bz));
end
MaxBz1=[MaxBz(1:21)+50,225,220,224,226,225.5];
ss=[20+160*tanh(t(1:14)/2.5e-11)';smooth(MaxBz(15:21))-50];