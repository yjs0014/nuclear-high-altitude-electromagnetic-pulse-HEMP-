gammaV=1.e8
V=0.95e8
E=27.8keV